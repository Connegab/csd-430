<%@ page import="java.sql.*" %>
<%@ page import="beans.MovieBean" %>

<%
    // Create MovieBean object
    MovieBean movieBean = null;
    ResultSet rs = null;
    ResultSet idSet = null;

    try {
        movieBean = new MovieBean();

        // Check if form was submitted
        String selectedId = request.getParameter("movieId");

        // If a movie was selected, delete it
        if (selectedId != null && !selectedId.equals("")) {
            int movieId = Integer.parseInt(selectedId);
            movieBean.deleteMovie(movieId);
        }

        // Retrieve updated records
        rs = movieBean.getAllMovies();
        idSet = movieBean.getAllMovieIds();

    } catch (Exception e) {
        out.println("Error: " + e.getMessage());
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Movie Records</title>
</head>
<body>

<h2>Movie Database Records</h2>

<p>This page displays all movie records. Select a Movie ID to delete a record.</p>

<!-- Display Movie Table -->
<table border="1">
    <thead>
        <tr>
            <th>Movie ID</th>
            <th>Title</th>
            <th>Director</th>
            <th>Release Year</th>
            <th>Genre</th>
        </tr>
    </thead>
    <tbody>

    <%
        boolean hasRecords = false;

        if (rs != null) {
            while (rs.next()) {
                hasRecords = true;
    %>

        <tr>
            <td><%= rs.getInt("movie_id") %></td>
            <td><%= rs.getString("title") %></td>
            <td><%= rs.getString("director") %></td>
            <td><%= rs.getInt("release_year") %></td>
            <td><%= rs.getString("genre") %></td>
        </tr>

    <%
            }
        }

        // If no records exist, table remains empty but header still shows
        if (!hasRecords) {
    %>
        <tr>
            <td colspan="5">No records remaining.</td>
        </tr>
    <%
        }
    %>

    </tbody>
</table>

<br><br>

<!-- Delete Form -->
<form method="post" action="deleteMovies.jsp">

    <label for="movieId">Select Movie ID to Delete:</label>

    <select name="movieId" required>
        <option value="">-- Select Movie ID --</option>

        <%
            if (idSet != null) {
                while (idSet.next()) {
        %>
            <option value="<%= idSet.getInt("movie_id") %>">
                <%= idSet.getInt("movie_id") %>
            </option>
        <%
                }
            }
        %>

    </select>

    <input type="submit" value="Delete Movie">

</form>

</body>
</html>