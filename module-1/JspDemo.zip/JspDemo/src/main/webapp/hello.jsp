<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My First JSP</title>
</head>
<body>
	<h1>JSP is working</h1>
	
	<%
		String name = request.getParameter("name");
		if (name == null || name.trim().isEmpty()) {
			name = "Student";
		}
		java.time.LocalDateTime now = java.time.LocalDateTime.now();
	%>
	
	
	<p> Hello, <strong><%= name %></strong>!</p>
	<p>Server time: <%= now %></p>
	
	<p>Try: <code>?name=Gabe</code></p>
</body>
</html>