<%@ page import="beans.MovieBean, java.sql.*" %>

<%
    MovieBean bean = new MovieBean();
    ResultSet ids = bean.getAllMovieIds();
%>

<html>
<head>
    <title>Select Movie to Update</title>
</head>
<body>

<h2>Select Movie Record to Update</h2>

<form action="updateForm.jsp" method="post">

<select name="movie_id">

<%
    while (ids.next()) {
%>
    <option value="<%= ids.getInt("movie_id") %>">
        Movie ID: <%= ids.getInt("movie_id") %>
    </option>
<%
    }
%>

</select>

<br><br>
<input type="submit" value="Edit Record">

</form>

</body>
</html>