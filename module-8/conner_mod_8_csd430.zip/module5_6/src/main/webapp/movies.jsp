<%@ page import="beans.MovieBean, java.sql.*" %>

<%
    // Initialize JavaBean
    MovieBean bean = new MovieBean();

    // Check if form was submitted
    String title = request.getParameter("title");

    if (title != null) {

        String director = request.getParameter("director");
        int releaseYear = Integer.parseInt(request.getParameter("release_year"));
        String genre = request.getParameter("genre");

        // Add movie to database
        bean.addMovie(title, director, releaseYear, genre);
    }

    // Get all movies for display
    ResultSet movies = bean.getAllMovies();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Movies Database - Add & View</title>
</head>
<body>

<h1>Movies Database Management</h1>

<p>Use the form below to add a new movie record. All movies in the database are displayed underneath.</p>

<h2>Add New Movie</h2>

<form method="post">

    Title: <input type="text" name="title" required><br><br>

    Director: <input type="text" name="director" required><br><br>

    Release Year: <input type="number" name="release_year" required><br><br>

    Genre: <input type="text" name="genre" required><br><br>

    <input type="submit" value="Add Movie">

</form>

<hr>

<h2>All Movie Records</h2>

<table border="1">
    <thead>
        <tr>
            <th>Movie ID</th>
            <th>Title</th>
            <th>Director</th>
            <th>Release Year</th>
            <th>Genre</th>
        </tr>
    </thead>
    <tbody>

        <%
            while (movies != null && movies.next()) {
        %>

        <tr>
            <td><%= movies.getInt("movie_id") %></td>
            <td><%= movies.getString("title") %></td>
            <td><%= movies.getString("director") %></td>
            <td><%= movies.getInt("release_year") %></td>
            <td><%= movies.getString("genre") %></td>
        </tr>

        <%
            }
        %>

    </tbody>
</table>

<p>This table displays all movie records currently stored in the database, and each column represents one field in the database.</p>

</body>
</html>
