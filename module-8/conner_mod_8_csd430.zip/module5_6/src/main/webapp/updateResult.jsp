<%@ page import="beans.MovieBean, java.sql.*" %>

<%
    int movieId = Integer.parseInt(request.getParameter("movie_id"));
    String title = request.getParameter("title");
    String director = request.getParameter("director");
    int releaseYear = Integer.parseInt(request.getParameter("release_year"));
    String genre = request.getParameter("genre");

    MovieBean bean = new MovieBean();
    bean.updateMovie(movieId, title, director, releaseYear, genre);

    ResultSet updated = bean.getMovieById(movieId);
    updated.next();
%>

<html>
<head>
    <title>Update Confirmation</title>
</head>
<body>

<h2>Movie Record Updated Successfully</h2>

<table border="1">
<tr>
    <th>movie_id (INT)</th>
    <th>title (VARCHAR)</th>
    <th>director (VARCHAR)</th>
    <th>release_year (INT)</th>
    <th>genre (VARCHAR)</th>
</tr>

<tr>
    <td><%= updated.getInt("movie_id") %></td>
    <td><%= updated.getString("title") %></td>
    <td><%= updated.getString("director") %></td>
    <td><%= updated.getInt("release_year") %></td>
    <td><%= updated.getString("genre") %></td>
</tr>

</table>

<br>
<a href="index.jsp">Return to Home</a>

</body>
</html>