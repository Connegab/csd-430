<html>
<head>
    <title>CSD430 Projects</title>
</head>
<body>

<h1>CSD430 Projects</h1>

<p>This project demonstrates database connectivity, JavaBeans, and JSP integration 
across multiple modules. Each module builds upon the previous one.</p>

<ul>
    <li><a href="#">Module 5 - Database Setup and Connection</a></li>
    <li><a href="#">Module 6 - JavaBean Integration</a></li>
    <li><a href="movies.jsp">Module 7 - Add and View Movies</a></li>
    <li><a href="updateSelect.jsp">Module 8 - Update Movie Record</a></li>
</ul>

<p>
Module 5 focused on creating the database and table structure.  
Module 6 introduced the JavaBean for database connectivity.  
Module 7 allowed users to add and view movie records.  
Module 8 now allows users to update existing movie records.
</p>

</body>
</html>