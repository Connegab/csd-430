<%@ page import="beans.MovieBean, java.sql.*" %>

<%
    int movieId = Integer.parseInt(request.getParameter("movie_id"));
    MovieBean bean = new MovieBean();
    ResultSet movie = bean.getMovieById(movieId);
    movie.next();
%>

<html>
<head>
    <title>Update Movie</title>
</head>
<body>

<h2>Update Movie Record</h2>

<form action="updateResult.jsp" method="post">

Movie ID (cannot change):
<input type="text" value="<%= movie.getInt("movie_id") %>" disabled>
<input type="hidden" name="movie_id" value="<%= movie.getInt("movie_id") %>">

<br><br>

Title:
<input type="text" name="title" value="<%= movie.getString("title") %>">

<br><br>

Director:
<input type="text" name="director" value="<%= movie.getString("director") %>">

<br><br>

Release Year:
<input type="number" name="release_year" value="<%= movie.getInt("release_year") %>">

<br><br>

Genre:
<input type="text" name="genre" value="<%= movie.getString("genre") %>">

<br><br>

<input type="submit" value="Update Movie">

</form>

</body>
</html>