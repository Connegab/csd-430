<!DOCTYPE html>
<html>
<head>
    <title>Job Application Form</title>
</head>

<body>

<h1>Job Application</h1>

<p>
    Please fill out the form below to apply for the position.
</p>

<form action="applicationResult.jsp" method="post">

    <label>Full Name:</label><br>
    <input type="text" name="name"><br><br>

    <label>Email Address:</label><br>
    <input type="email" name="email"><br><br>

    <label>Years of Experience:</label><br>
    <input type="number" name="experience"><br><br>

    <label>Position Applying For:</label><br>
    <select name="position">
        <option value="Developer">Developer</option>
        <option value="Analyst">Analyst</option>
        <option value="Support">Support</option>
    </select><br><br>

    <label>Additional Comments:</label><br>
    <textarea name="comments" rows="4" cols="30"></textarea><br><br>

    <input type="submit" value="Submit Application">

</form>

</body>
</html>
