<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<%
    String name = request.getParameter("name");
    String email = request.getParameter("email");
    String experience = request.getParameter("experience");
    String position = request.getParameter("position");
    String comments = request.getParameter("comments");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Application Submitted</title>
</head>

<body>

<h1>Application Summary</h1>

<p>
    Below is the information submitted from the job application form.
</p>

<table border="1" cellpadding="8">
    <tr>
        <th>Field</th>
        <th>Submitted Data</th>
    </tr>
    <tr>
        <td>Full Name</td>
        <td><%= name %></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><%= email %></td>
    </tr>
    <tr>
        <td>Years of Experience</td>
        <td><%= experience %></td>
    </tr>
    <tr>
        <td>Position</td>
        <td><%= position %></td>
    </tr>
    <tr>
        <td>Comments</td>
        <td><%= comments %></td>
    </tr>
</table>

</body>
</html>
