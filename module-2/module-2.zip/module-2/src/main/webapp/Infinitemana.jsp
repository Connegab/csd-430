<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<%
    String title = "Infinite Mana in the Apocalypse";
    String author = "Adhanom";
    int currentChapter = 3217;

    String[] arcName = {
        "Early Cultivation",
        "Multiversal Growth",
        "Cosmic Dao",
        "Infinite Realities",
        "Apocalypse Phase"
    };

    String[] arcFocus = {
        "Learning cultivation basics",
        "Scaling across universes",
        "Understanding Dao powers",
        "Reality-level abilities",
        "Endgame conflicts"
    };
%>

<!DOCTYPE html>
<html>
<head>
    <title>Infinite Mana in the Apocalypse</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

<h1><%= title %></h1>

<p>
    This page shows my progress reading <strong><%= title %></strong> by
    <%= author %>. I am currently around chapter <%= currentChapter %> and have
    been reading it for a couple of years. The Webnovel may call it chapters, but 
    when I say that it really is just pages.
</p>

<h2>Story Arcs</h2>

<table>
    <tr>
        <th>Arc</th>
        <th>Main Focus</th>
    </tr>

<%
    for (int i = 0; i < arcName.length; i++) {
%>
    <tr>
        <td><%= arcName[i] %></td>
        <td><%= arcFocus[i] %></td>
    </tr>
<%
    }
%>

</table>

</body>
</html>
