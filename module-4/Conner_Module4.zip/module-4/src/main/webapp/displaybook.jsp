<%@ page import="BookBeans.BookBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Book Reading Progress</title>
    <style>
        table {
            border-collapse: collapse;
            width: 60%;
        }
        th, td {
            border: 1px solid #444;
            padding: 8px;
        }
        th {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<h2>Book Reading Data</h2>
<p>This table shows my current progress on the book I talked about which I have been reading for a few years.</p>

<%
    // Create and populate the JavaBean
    BookBean book = new BookBean();
    book.setTitle("Infinite Mana in the Apocalypse");
    book.setAuthor("Adonis");
    book.setChaptersRead(3217);
    book.setTotalChapters(3500);
    book.setReadingTime("2 - 3 years");
%>

<table>
    <tr>
        <th>Field</th>
        <th>Value</th>
    </tr>
    <tr>
        <td>Title</td>
        <td><%= book.getTitle() %></td>
    </tr>
    <tr>
        <td>Author</td>
        <td><%= book.getAuthor() %></td>
    </tr>
    <tr>
        <td>Chapters Read</td>
        <td><%= book.getChaptersRead() %></td>
    </tr>
    <tr>
        <td>Total Chapters</td>
        <td><%= book.getTotalChapters() %></td>
    </tr>
    <tr>
        <td>Time Spent Reading</td>
        <td><%= book.getReadingTime() %></td>
    </tr>
</table>

</body>
</html>
