package BookBeans;

import java.io.Serializable;

/*
 * The javaBean to store book information
 */
public class BookBean implements Serializable {

    private String title;
    private String author;
    private int chaptersRead;
    private int totalChapters;
    private String readingTime;

    // no-arg constructor
    public BookBean() {}

    // The getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getChaptersRead() {
        return chaptersRead;
    }

    public void setChaptersRead(int chaptersRead) {
        this.chaptersRead = chaptersRead;
    }

    public int getTotalChapters() {
        return totalChapters;
    }

    public void setTotalChapters(int totalChapters) {
        this.totalChapters = totalChapters;
    }

    public String getReadingTime() {
        return readingTime;
    }

    public void setReadingTime(String readingTime) {
        this.readingTime = readingTime;
    }
}
