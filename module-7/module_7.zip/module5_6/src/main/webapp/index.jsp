<html>
<head>
    <title>CSD430 Projects</title>
</head>
<body>

<h1>CSD430 Projects</h1>

<ul>
    <li><a href="movies.jsp">Module 7 – Add and View Movies</a></li>
</ul>

<p>This assignment will allow users to add new movie records and view all movie data stored in the database.</p>

</body>
</html>
