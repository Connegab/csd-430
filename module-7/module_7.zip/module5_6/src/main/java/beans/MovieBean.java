package beans;

import java.sql.*;

public class MovieBean {

    private Connection conn;

    public MovieBean() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/CSD430",
            "student1",
            "pass"
        );
    }

    // Get all movie IDs
    public ResultSet getAllMovieIds() throws SQLException {
        String sql = "SELECT movie_id FROM gabe_movies_data";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
    }

 // Insert new movie record
    public void addMovie(String title, String director, int releaseYear, String genre) {
        try {
            String sql = "INSERT INTO gabe_movies_data (title, director, release_year, genre) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, director);
            ps.setInt(3, releaseYear);
            ps.setString(4, genre);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Retrieve all movie records
    public ResultSet getAllMovies() {
        try {
            String sql = "SELECT * FROM gabe_movies_data";
            PreparedStatement ps = conn.prepareStatement(sql);
            return ps.executeQuery();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get one movie by ID
    public ResultSet getMovieById(int movieId) throws SQLException {
        String sql = "SELECT * FROM gabe_movies_data WHERE movie_id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, movieId);
        return pstmt.executeQuery();
    }
}
