<%@ page import="beans.MovieBean, java.sql.*" %>

<%
    // Initialize the JavaBean
    MovieBean bean = new MovieBean();

    // Get all movie IDs for the dropdown
    ResultSet idResults = bean.getAllMovieIds();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Movies Database</title>
</head>
<body>

<h1>Movies Database</h1>
<p>Select a movie ID to view the movie details.</p>

<!-- Dropdown Form -->
<form method="post">
    <select name="movieId">
        <%
            while (idResults.next()) {
        %>
            <option value="<%= idResults.getInt("movie_id") %>">
                <%= idResults.getInt("movie_id") %>
            </option>
        <%
            }
        %>
    </select>
    <input type="submit" value="View Movie">
</form>

<%
    // Handle form submission
    String movieIdParam = request.getParameter("movieId");
    if (movieIdParam != null) {
        int movieId = Integer.parseInt(movieIdParam);
        ResultSet movie = bean.getMovieById(movieId);
%>

<h2>Movie Details</h2>

<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Director</th>
            <th>Release Year</th>
            <th>Genre</th>
        </tr>
    </thead>
    <tbody>
        <%
            while (movie.next()) {
        %>
        <tr>
            <td><%= movie.getInt("movie_id") %></td>
            <td><%= movie.getString("title") %></td>
            <td><%= movie.getString("director") %></td>
            <td><%= movie.getInt("release_year") %></td>
            <td><%= movie.getString("genre") %></td>
        </tr>
        <%
            }
        %>
    </tbody>
</table>

<%
    }
%>

</body>
</html>
