<!DOCTYPE html>
<html>
<head>
    <title>CSD430 Projects</title>
</head>
<body>

<h1>CSD430 Projects</h1>

<ul>
    <li><a href="movies.jsp">Module 5&6 – Movies Database</a></li>
</ul>

</body>
</html>
