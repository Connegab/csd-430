package beans;

import java.sql.*;

public class MovieBean {

    private Connection conn;

    public MovieBean() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/CSD430",
            "student1",
            "pass"
        );
    }

    public ResultSet getAllMovieIds() throws SQLException {
        String sql = "SELECT movie_id FROM gabe_movies_data";
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
    }

    public ResultSet getMovieById(int movieId) throws SQLException {
        String sql = "SELECT * FROM gabe_movies_data WHERE movie_id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, movieId);
        return pstmt.executeQuery();
    }
}
